import stdio
import stdrandom

...
