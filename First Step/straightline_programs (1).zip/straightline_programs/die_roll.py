import stdio
import stdrandom
import sys

...
