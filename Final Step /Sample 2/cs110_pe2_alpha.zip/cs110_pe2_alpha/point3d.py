import math
import stdio


# An immutable data type to represent a point in 3D space.
class Point3D:
    # Constructs a Point3D object given its x, y, and z coordinates.
    def __init__(self, x=0, y=0, z=0):
        ...

    # Returns the distance of this point to the origin.
    def distToOrigin(self):
        ...

    # Returns the distance of this point to other.
    def distTo(self, other):
        ...

    # Returns a Point3D object whose x, y, and z coordinates are the negative of this point's x, y, and z coordinates.
    def flip(self):
        ...

    # Returns True if this point's distance to the origin is less than the other point's distance to the origin; and 
    # False otherwise.
    def __lt__(self, other):
        ...

    # Returns True if this point and other have the same distance to the origin; and False otherwise.
    def __eq__(self, other):
        ...

    # Returns a string representation of this point.
    def __str__(self):
        ...

# Unit tests the data type.
def _main():
    p1 = Point3D(1, 0)
    p2 = Point3D(0, 1)
    stdio.writeln(p1)
    stdio.writeln(p2)
    stdio.writeln(p1.distTo(p2))
    stdio.writeln(p1.flip())
    stdio.writeln(p1 < p2)
    stdio.writeln(p1 == p2)

if __name__ == "__main__":
    _main()
