from point3d import Point3D
import stdio
import sys

# Entry point.
def main():
    ...

if __name__ == "__main__":
    main()
