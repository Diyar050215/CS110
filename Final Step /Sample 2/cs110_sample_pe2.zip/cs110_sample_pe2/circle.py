import math

class Circle:
    # Constructs a circle of radius r centered at (h, k); when no arguments are given, the circle
    # is a unit circle centered at the origin.
    def __init__(self, h=0, k=0, r=1):
        ...

    # Returns the area of this circle.
    def area(self):
        ...

    # Returns the circumference of this circle.
    def circumference(self):
        ...

    # Returns True if this circle contains the point (x, y) and False otherwise.
    def contains(self, x, y):
        ...

    # Returns a new circle whose center is the same as this circle, but with radius r.
    def scale(self, r):
        ...

    # Returns the Euclidean distance between the centers of this circle and other.
    def distanceTo(self, other):
        ...

    # Returns True if this circle is the same as other (ie, they have the same centers and radii)
    # and False otherwise.
    def __eq__(self, other):
        ...

    # Returns True if this circle's area is smaller than other's area and False otherwise.
    def __lt__(self, other):
        ...

    # Returns a string representation of this circle.
    def __str__(self):
        ...

# Unit tests the data type.
def _main():
    import stdio

    c = Circle()
    d = Circle(1, 1, 2)
    stdio.writeln(c)
    stdio.writeln(d)
    stdio.writeln(c.area())
    stdio.writeln(c.circumference())
    stdio.writeln(c.contains(1, 1))
    stdio.writeln(c.scale(2))
    stdio.writeln(c.distanceTo(d))
    stdio.writeln(c == d or c == c)
    stdio.writeln(d < c)

if __name__ == "__main__":
    _main()
