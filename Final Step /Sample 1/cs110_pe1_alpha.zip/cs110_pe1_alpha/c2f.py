import stdio
import sys

...

