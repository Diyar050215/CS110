import stdio
import strops
import sys

...
