from markov_model import MarkovModel
import stdio
import sys

# Entry point.
def main():
    ...

if __name__ == "__main__":
    main()
