from instream import InStream
from symboltable import SymbolTable
import stdio
import sys

# Entry point.
def main():
    ...
    
if __name__ == "__main__":
    main()
