from instream import InStream
from symboltable import SymbolTable
import stdio


# Entry point.
def main():
    ...

if __name__ == "__main__":
    main()
